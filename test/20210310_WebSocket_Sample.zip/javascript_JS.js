/*--------------------------------------------------------------------------
 *
 *  Webcrea : ActiveSoft Web Version 7, 0, 2020, 1012, 001
 *
 *  (c) Copyright 2015. ActiveSoft. Co., Ltd.
 *  For details, see the activesoft web site: http://www.activesoft.co.kr
 *
 *--------------------------------------------------------------------------*/

gPortConnectIdx =0;

function fn_sleep(delay) {
	var start = new Date().getTime();
	while (new Date().getTime() < start + delay);
}

/**
 * 현재 도메인을 가지고 주소를 구한다..
 * 
 * @param  : 
 * @return : 현재 주소
 */
function fn_getURL(){
    var url = window.document.URL;
    return url;
}

function fn_send(pToken)
{
	ws.send(pToken);
}

function fn_getVersion()
{
	ws.send('version');  
	ws.send('comment');
}

function fn_Disconnect()
{
//	ws.close();
}

function fn_WSConnect()
{

	gPortConnectIdx = gPortConnectIdx+1;	
	if(gPortConnectIdx == 1){
		fn_Connect("17021");
		
	}else if(gPortConnectIdx == 2){
		fn_Connect("17020");
		
	}else if(gPortConnectIdx == 3){
		fn_Connect("17030");
		
	}else if(gPortConnectIdx == 4){
		fn_Connect("17031");
		
	}else if(gPortConnectIdx > 4){
		//MyBrowserManager 설치페이지로 이동
		alert("설치페이지로 이동");
	}
}

function fn_connectSuccess()
{
	//MyBrowserManager에게 Command 전달
	//전용브라우저_배포가이드 page9 참조.
	ws.send("reset");
	 fn_sleep(0.1); //sleep은 꼭 필요합니다.
	ws.send("/h C:\\ActiveSoft\\MyBuilderDemo-MDI");
	 fn_sleep(0.1);
	ws.send("/bin http://www.activesoft.co.kr/demo/Biin");
	 fn_sleep(0.1);
	ws.send("/s http://www.activesoft.co.kr/demo/Files_MDI");
	 fn_sleep(0.1);
	ws.send("/h C:\\ActiveSoft\\MyBuilderDemo-MDI");
	 fn_sleep(0.1);
	ws.send("run MyBrowserPlus.exe");		//run command 이후에는 소켓의 onmessage 이벤트 발생
	
}
//정상 메세지 수신
function fn_message(pMsg)
{
	if(pMsg =="OK"){ //run 이후에 정상 동작여부
		fn_Disconnect()
	}else{
		alert(pMsg);
	}
}

//오류 메세지
function fn_errorMessage(pMsg)
{
	alert(pMsg);
}

function fn_Connect(pSocketUrl){

	var v_socket = 'ws://127.0.0.1:' + pSocketUrl;  //ex.WebSocket("ws://127.0.0.1:12059");
	ws = new WebSocket(v_socket);

	//웹표준 Function
	ws.onopen=function(){
		fn_connectSuccess();
	};

	//웹표준 Function
	ws.onmessage = function (e){
		fn_message(e.data);
	};

	//웹표준 Function
	ws.onclose = function (e) {
//		fn_message(e.data);
	};

	//웹표준 Function
	ws.onerror = function (e) {	
		if(gPortConnectIdx <=4){
			fn_WSConnect();
		}else{
			fn_errorMessage(e.data);
		}
		
	}
}
